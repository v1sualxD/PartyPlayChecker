# Party Play Checker

POEFixer plugin source (SDK v6), built as an x64 DLL with Visual Studio 2022 / MSVC v143.

## Features

- Draws a projected circle around your character using the selected range.
- Can color the circle green or red based on whether the chosen minimum number of players is inside the range.
- Shows a draggable in-game window with detected player names, measured distances, and `IN ZONE` / `OUT OF ZONE` status.
- Provides a `PARTY PLAY` setting that fixes the threshold at 13 m and restores your previous custom threshold when turned off.
- Can hide the range circle and status window in towns and hideouts.
- Offers independent sound alerts when a detected player enters or leaves the selected range.
- Saves named profiles containing the range and plugin options, and lets you select a saved profile to load it.
- Includes an optional performance debug window with update time, average and peak time, entity scan time, and entity/player counts.
- Saves the selected settings beside the plugin in `settings.ini`.

## Range accuracy

Distances are calculated from the horizontal player world coordinates and displayed to 0.1 m. Path of Exile 2's public party references do not confirm one universal numeric range for XP and loot. The 13 m Party Play setting is a provisional reference from Path of Exile 1, not a confirmed PoE 2 threshold. The SDK also does not expose party membership or actual XP/loot eligibility.

References: [PoE 2 party mechanics](https://www.poe2wiki.net/wiki/Party), [PoE 2 distance units](https://www.poe2wiki.net/wiki/Nearby), [PoE 1 party loot range](https://www.poewiki.net/wiki/Partying).

## Build and install

Open `PartyPlayChecker.sln`, select `Release | x64`, and build. The output is `x64/Release/Plugins/PartyPlayChecker/PartyPlayChecker.dll`.

To install through POEFixer, publish `vX.Y.Z` as a GitHub release with an asset named `PartyPlayChecker.zip`. The zip must contain `Plugins/PartyPlayChecker/PartyPlayChecker.dll`.

The SDK and ImGui sources in `POEFixer/` are included. See `LICENSE` for upstream licensing and attribution.

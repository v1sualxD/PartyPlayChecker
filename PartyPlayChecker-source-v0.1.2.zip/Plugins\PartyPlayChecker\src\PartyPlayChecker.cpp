#include "../../../POEFixer/imgui/imgui.h"
#include "../../../POEFixer/plugin_sdk/PluginSDK.h"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cmath>
#include <fstream>
#include <string>
#include <unordered_map>
#include <vector>

POEFIXER_PLUGIN_INFO(
    "PartyPlayChecker",
    "Party Play Checker",
    "0.1.2",
    "PartyPlayChecker contributors",
    "Shows nearby player distances, range status, and an in-game party range circle.")

namespace {

constexpr float kPartyPlayRangeMeters = 13.0f;
constexpr int kRangeCircleSegments = 64;

struct NearbyPlayer {
    std::string name;
    float distanceMeters = 0.0f;
    uint32_t id = 0;
};

std::string ToUtf8(const std::wstring& value) {
    if (value.empty()) return {};
    const int needed = WideCharToMultiByte(CP_UTF8, 0, value.data(),
        static_cast<int>(value.size()), nullptr, 0, nullptr, nullptr);
    if (needed <= 0) return {};
    std::string result(static_cast<size_t>(needed), '\0');
    WideCharToMultiByte(CP_UTF8, 0, value.data(), static_cast<int>(value.size()),
        result.data(), needed, nullptr, nullptr);
    return result;
}

} // namespace

class PartyPlayChecker final : public PluginSDK::Plugin {
public:
    const char* GetName() const override { return "Party Play Checker"; }
    bool WantsOverlay() const override { return true; }

    void OnEnable(bool) override {
        if (ctx()->ImGuiContext)
            ImGui::SetCurrentContext(static_cast<ImGuiContext*>(ctx()->ImGuiContext));
        LoadSettings();
    }

    void OnDisable() override { SaveSettings(); }

    void SaveSettings() override {
        SaveSettingsToPath(DirectoryPath() / L"settings.ini");
    }

    bool SaveSettingsToPath(const std::filesystem::path& path) const {
        std::ofstream file(path, std::ios::trunc);
        if (!file) return false;
        file << "custom_distance_limit_m=" << m_customDistanceLimitMeters << '\n';
        file << "party_play_mode=" << (m_partyPlayMode ? 1 : 0) << '\n';
        file << "show_overlay=" << (m_showOverlay ? 1 : 0) << '\n';
        file << "maps_only=" << (m_mapsOnly ? 1 : 0) << '\n';
        file << "sound_on_enter=" << (m_soundOnEnter ? 1 : 0) << '\n';
        file << "sound_on_exit=" << (m_soundOnExit ? 1 : 0) << '\n';
        file << "show_performance_debug=" << (m_showPerformanceDebug ? 1 : 0) << '\n';
        file << "zone_color_enabled=" << (m_zoneColorEnabled ? 1 : 0) << '\n';
        file << "minimum_players_for_green=" << m_minimumPlayersForGreen << '\n';
        return static_cast<bool>(file);
    }

    void DrawSettings() override {
        if (ctx()->ImGuiContext)
            ImGui::SetCurrentContext(static_cast<ImGuiContext*>(ctx()->ImGuiContext));

        ImGui::TextUnformatted("Party Play Checker");
        ImGui::TextWrapped("Shows the horizontal distance to detected players, their range status, and a circle around your character.");
        ImGui::Spacing();

        bool partyPlay = m_partyPlayMode;
        if (ImGui::Checkbox("PARTY PLAY", &partyPlay)) {
            if (partyPlay) {
                if (!m_partyPlayMode) m_customDistanceLimitMeters = m_distanceLimitMeters;
                m_partyPlayMode = true;
                m_distanceLimitMeters = kPartyPlayRangeMeters;
            } else {
                m_partyPlayMode = false;
                m_distanceLimitMeters = m_customDistanceLimitMeters;
            }
        }

        if (m_partyPlayMode) {
            ImGui::Text("Party Play range: fixed at %.1f m.", kPartyPlayRangeMeters);
            ImGui::TextWrapped("This is a provisional PoE 2 threshold, not a confirmed universal party range.");
        } else if (ImGui::SliderFloat("Range threshold", &m_distanceLimitMeters, 1.0f, 100.0f, "%.1f m")) {
            m_customDistanceLimitMeters = m_distanceLimitMeters;
        }

        ImGui::Checkbox("Show the window and range circle in game", &m_showOverlay);
        ImGui::Checkbox("Show range only in maps", &m_mapsOnly);
        ImGui::TextWrapped("When enabled, the window and circle are hidden in towns and hideouts.");
        ImGui::Checkbox("Color the circle based on players in range", &m_zoneColorEnabled);
        ImGui::SliderInt("Minimum players for green", &m_minimumPlayersForGreen, 1, 5);
        ImGui::TextWrapped("The circle is green when the minimum is met, and red otherwise.");
        ImGui::Checkbox("Play a sound when a player enters the range", &m_soundOnEnter);
        ImGui::Checkbox("Play a sound when a player leaves the range", &m_soundOnExit);
        ImGui::Checkbox("Show performance debug window", &m_showPerformanceDebug);
        ImGui::Text("Plugin update: %.3f ms avg | %.3f ms peak", m_averageUpdateMs,
            m_peakUpdateMs);
        ImGui::Text("Entity scan: %.3f ms | %zu entities | %zu players",
            m_lastEntityScanMs, m_lastEntityCount, m_lastPlayerCount);

        ImGui::Spacing();
        ImGui::SeparatorText("Profiles");
        ImGui::SetNextItemWidth(220.0f);
        ImGui::InputText("Profile name", m_profileName, sizeof(m_profileName));
        if (ImGui::Button("Save profile")) SaveProfile();
        if (!m_profileMessage.empty()) ImGui::TextWrapped("%s", m_profileMessage.c_str());
        const auto profiles = ListProfiles();
        if (ImGui::BeginCombo("Saved profile", m_selectedProfile.empty()
                ? "Select a profile" : m_selectedProfile.c_str())) {
            for (const auto& profile : profiles) {
                const bool selected = profile == m_selectedProfile;
                if (ImGui::Selectable(profile.c_str(), selected)) {
                    m_selectedProfile = profile;
                    LoadProfile(profile);
                }
                if (selected) ImGui::SetItemDefaultFocus();
            }
            ImGui::EndCombo();
        }
        ImGui::TextWrapped("Distances are calculated from player world coordinates and rounded to 0.1 m. The SDK does not report party membership or confirm XP and loot eligibility.");
        if (ImGui::Button("Save settings")) SaveSettings();
    }

    void DrawUI() override {
        if (!ctx()->Game.IsInGame() || (m_mapsOnly && ctx()->Game.IsTownOrHideout())) {
            m_previousZoneStates.clear();
            m_zoneStateInitialized = false;
            return;
        }
        if (ctx()->ImGuiContext)
            ImGui::SetCurrentContext(static_cast<ImGuiContext*>(ctx()->ImGuiContext));
        const auto frameStart = std::chrono::steady_clock::now();

        const PluginSDK::Entity self = ctx()->Entities.GetPlayer();
        if (!self.IsValid || self.EntitySubtype != PluginSDK::EntitySubtype::PlayerSelf) {
            RecordPerformance(frameStart, 0.0);
            if (m_showPerformanceDebug && ctx()->Game.IsForeground()) DrawPerformanceWindow();
            return;
        }

        std::vector<NearbyPlayer> players;
        size_t entityCount = 0;
        const auto scanStart = std::chrono::steady_clock::now();
        ctx()->Entities.Enumerate([&](const PluginSDK::Entity& entity) {
            ++entityCount;
            if (!entity.IsValid || entity.EntityType != PluginSDK::EntityType::Player ||
                entity.EntitySubtype != PluginSDK::EntitySubtype::PlayerOther ||
                entity.RenderComponentAddress == 0)
                return true;

            const float dx = entity.WorldX - self.WorldX;
            const float dy = entity.WorldY - self.WorldY;
            const float distance = std::sqrt(dx * dx + dy * dy);
            if (!std::isfinite(distance)) return true;

            std::string name = ToUtf8(entity.PlayerName);
            if (name.empty()) name = "Player with no name";
            players.push_back({ std::move(name), distance, entity.Id });
            return true;
        });
        m_lastEntityScanMs = std::chrono::duration<double, std::milli>(
            std::chrono::steady_clock::now() - scanStart).count();
        m_lastEntityCount = entityCount;
        m_lastPlayerCount = players.size();

        std::sort(players.begin(), players.end(), [](const auto& a, const auto& b) {
            return a.distanceMeters < b.distanceMeters;
        });

        m_playersInZone = static_cast<size_t>(std::count_if(players.begin(), players.end(),
            [this](const NearbyPlayer& player) {
                return player.distanceMeters <= m_distanceLimitMeters;
            }));
        UpdateZoneTransitions(players);
        if (m_showOverlay && ctx()->Game.IsForeground()) {
            DrawRangeCircle(self);
            DrawStatusWindow(players);
        }
        RecordPerformance(frameStart, m_lastEntityScanMs);
        if (m_showPerformanceDebug && ctx()->Game.IsForeground()) DrawPerformanceWindow();
    }

private:
    void DrawRangeCircle(const PluginSDK::Entity& self) const {
        std::vector<ImVec2> points;
        points.reserve(kRangeCircleSegments);

        for (int i = 0; i < kRangeCircleSegments; ++i) {
            const float angle = (2.0f * IM_PI * static_cast<float>(i)) /
                static_cast<float>(kRangeCircleSegments);
            const float worldX = self.WorldX + std::cos(angle) * m_distanceLimitMeters;
            const float worldY = self.WorldY + std::sin(angle) * m_distanceLimitMeters;
            float screenX = 0.0f;
            float screenY = 0.0f;
            if (!ctx()->Render.WorldToScreen(worldX, worldY, self.WorldZ, screenX, screenY))
                return;
            points.emplace_back(screenX, screenY);
        }

        ImDrawList* drawList = ctx()->Game.IsMenuVisible()
            ? ImGui::GetBackgroundDrawList()
            : ImGui::GetForegroundDrawList();
        const ImVec4 circleColor = !m_zoneColorEnabled
            ? ImVec4(0.35f, 0.72f, 1.0f, 0.82f)
            : (m_playersInZone >= static_cast<size_t>(m_minimumPlayersForGreen)
                ? ImVec4(0.22f, 0.95f, 0.38f, 0.90f)
                : ImVec4(1.0f, 0.20f, 0.20f, 0.90f));
        const ImU32 color = ImGui::ColorConvertFloat4ToU32(circleColor);
        drawList->AddPolyline(points.data(), static_cast<int>(points.size()), color,
            ImDrawFlags_Closed, 2.0f);
    }

    void UpdateZoneTransitions(const std::vector<NearbyPlayer>& players) {
        std::unordered_map<uint32_t, bool> currentStates;
        currentStates.reserve(players.size());
        bool entered = false;
        bool exited = false;

        for (const auto& player : players) {
            const bool inZone = player.distanceMeters <= m_distanceLimitMeters;
            currentStates[player.id] = inZone;
            const auto previous = m_previousZoneStates.find(player.id);
            if (!m_zoneStateInitialized || previous == m_previousZoneStates.end()) continue;
            if (!previous->second && inZone) entered = true;
            if (previous->second && !inZone) exited = true;
        }

        if (m_zoneStateInitialized) {
            if (entered && m_soundOnEnter) MessageBeep(MB_ICONASTERISK);
            if (exited && m_soundOnExit) MessageBeep(MB_ICONEXCLAMATION);
        }
        m_previousZoneStates = std::move(currentStates);
        m_zoneStateInitialized = true;
    }

    void RecordPerformance(std::chrono::steady_clock::time_point frameStart, double scanMs) {
        m_lastEntityScanMs = scanMs;
        m_lastUpdateMs = std::chrono::duration<double, std::milli>(
            std::chrono::steady_clock::now() - frameStart).count();
        if (m_performanceSamples == 0) m_averageUpdateMs = m_lastUpdateMs;
        else m_averageUpdateMs += (m_lastUpdateMs - m_averageUpdateMs) * 0.05;
        m_peakUpdateMs = std::max(m_peakUpdateMs, m_lastUpdateMs);
        ++m_performanceSamples;
    }

    void DrawPerformanceWindow() const {
        ImGui::SetNextWindowBgAlpha(0.90f);
        const ImGuiWindowFlags flags = ImGuiWindowFlags_AlwaysAutoResize |
            ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoFocusOnAppearing |
            ImGuiWindowFlags_NoNav;
        if (!ImGui::Begin("Performance Debug###PartyPlayCheckerPerformance", nullptr, flags)) {
            ImGui::End();
            return;
        }
        ImGui::Text("Plugin update: %.3f ms (avg %.3f / peak %.3f)", m_lastUpdateMs,
            m_averageUpdateMs, m_peakUpdateMs);
        ImGui::Text("Entity scan: %.3f ms", m_lastEntityScanMs);
        ImGui::Text("Entities scanned: %zu", m_lastEntityCount);
        ImGui::Text("Players detected: %zu", m_lastPlayerCount);
        ImGui::Text("Samples: %llu", static_cast<unsigned long long>(m_performanceSamples));
        ImGui::End();
    }

    std::filesystem::path ProfilesDirectory() const {
        return DirectoryPath() / L"profiles";
    }

    std::vector<std::string> ListProfiles() const {
        std::vector<std::string> profiles;
        std::error_code error;
        const auto directory = ProfilesDirectory();
        if (!std::filesystem::exists(directory, error)) return profiles;
        for (std::filesystem::directory_iterator it(directory, error), end;
             !error && it != end; it.increment(error)) {
            if (it->is_regular_file(error) && it->path().extension() == ".ini")
                profiles.push_back(it->path().stem().string());
        }
        std::sort(profiles.begin(), profiles.end());
        return profiles;
    }

    void SaveProfile() {
        std::string name(m_profileName);
        while (!name.empty() && name.back() == ' ') name.pop_back();
        const auto first = name.find_first_not_of(' ');
        if (first != std::string::npos) name.erase(0, first);
        if (name.empty()) {
            m_profileMessage = "Enter a profile name first.";
            return;
        }
        for (char& character : name) {
            const unsigned char value = static_cast<unsigned char>(character);
            if (!(std::isalnum(value) || character == ' ' || character == '-' || character == '_'))
                character = '_';
        }

        std::error_code error;
        const auto directory = ProfilesDirectory();
        std::filesystem::create_directories(directory, error);
        if (error) {
            m_profileMessage = "Could not create the profiles folder.";
            return;
        }
        const auto path = directory / (name + ".ini");
        if (!SaveSettingsToPath(path)) {
            m_profileMessage = "Could not save the profile.";
            return;
        }
        m_selectedProfile = name;
        m_profileMessage = "Profile saved.";
    }

    void LoadProfile(const std::string& name) {
        const auto directory = ProfilesDirectory();
        const auto profiles = ListProfiles();
        if (std::find(profiles.begin(), profiles.end(), name) == profiles.end()) return;
        LoadSettingsFromPath(directory / (name + ".ini"));
        SaveSettings();
        m_profileMessage = "Profile loaded.";
    }

    void DrawStatusWindow(const std::vector<NearbyPlayer>& players) const {
        ImGui::SetNextWindowPos(ImVec2(24.0f, 80.0f), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowBgAlpha(0.88f);
        const ImGuiWindowFlags flags = ImGuiWindowFlags_AlwaysAutoResize |
            ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoFocusOnAppearing |
            ImGuiWindowFlags_NoNav;

        if (!ImGui::Begin("Party Play Checker###PartyPlayCheckerStatus", nullptr, flags)) {
            ImGui::End();
            return;
        }

        ImGui::Text("Range: %.1f m%s", m_distanceLimitMeters,
            m_partyPlayMode ? "  |  PARTY PLAY" : "");
        ImGui::Separator();

        if (players.empty()) {
            ImGui::TextUnformatted("No other players detected in this area.");
        } else {
            for (const auto& player : players) {
                const bool inZone = player.distanceMeters <= m_distanceLimitMeters;
                const ImVec4 color = inZone ? ImVec4(0.30f, 0.92f, 0.48f, 1.0f)
                                            : ImVec4(1.0f, 0.55f, 0.34f, 1.0f);
                ImGui::TextColored(color, "%s  %.1f m  %s", player.name.c_str(),
                    player.distanceMeters, inZone ? "IN ZONE" : "OUT OF ZONE");
            }
        }
        ImGui::End();
    }

    void LoadSettings() {
        LoadSettingsFromPath(DirectoryPath() / L"settings.ini");
    }

    void LoadSettingsFromPath(const std::filesystem::path& path) {
        std::ifstream file(path);
        std::string line;
        while (std::getline(file, line)) {
            const auto split = line.find('=');
            if (split == std::string::npos) continue;
            const std::string key = line.substr(0, split);
            const std::string value = line.substr(split + 1);

            if (key == "custom_distance_limit_m" || key == "distance_limit_m") {
                try {
                    const float parsed = std::stof(value);
                    if (std::isfinite(parsed))
                        m_customDistanceLimitMeters = std::clamp(parsed, 1.0f, 100.0f);
                } catch (...) {}
            } else if (key == "party_play_mode") {
                m_partyPlayMode = value != "0";
            } else if (key == "show_overlay") {
                m_showOverlay = value != "0";
            } else if (key == "maps_only") {
                m_mapsOnly = value != "0";
            } else if (key == "sound_on_enter") {
                m_soundOnEnter = value != "0";
            } else if (key == "sound_on_exit") {
                m_soundOnExit = value != "0";
            } else if (key == "show_performance_debug") {
                m_showPerformanceDebug = value != "0";
            } else if (key == "zone_color_enabled") {
                m_zoneColorEnabled = value != "0";
            } else if (key == "minimum_players_for_green") {
                try {
                    m_minimumPlayersForGreen = std::clamp(std::stoi(value), 1, 5);
                } catch (...) {}
            }
        }

        m_distanceLimitMeters = m_partyPlayMode
            ? kPartyPlayRangeMeters
            : m_customDistanceLimitMeters;
    }

    float m_distanceLimitMeters = kPartyPlayRangeMeters;
    float m_customDistanceLimitMeters = kPartyPlayRangeMeters;
    bool m_partyPlayMode = false;
    bool m_showOverlay = true;
    bool m_mapsOnly = false;
    bool m_soundOnEnter = false;
    bool m_soundOnExit = false;
    bool m_showPerformanceDebug = false;
    bool m_zoneColorEnabled = true;
    int m_minimumPlayersForGreen = 1;
    size_t m_playersInZone = 0;
    bool m_zoneStateInitialized = false;
    std::unordered_map<uint32_t, bool> m_previousZoneStates;
    char m_profileName[64] = {};
    std::string m_selectedProfile;
    std::string m_profileMessage;
    double m_lastUpdateMs = 0.0;
    double m_lastEntityScanMs = 0.0;
    double m_averageUpdateMs = 0.0;
    double m_peakUpdateMs = 0.0;
    size_t m_lastEntityCount = 0;
    size_t m_lastPlayerCount = 0;
    uint64_t m_performanceSamples = 0;
};

extern "C" PLUGIN_API PluginSDK::Plugin* CreatePlugin() { return new PartyPlayChecker(); }
extern "C" PLUGIN_API void DestroyPlugin(PluginSDK::Plugin* plugin) { delete plugin; }

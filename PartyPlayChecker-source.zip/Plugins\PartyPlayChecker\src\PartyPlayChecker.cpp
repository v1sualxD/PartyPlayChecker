#include "../../../POEFixer/imgui/imgui.h"
#include "../../../POEFixer/plugin_sdk/PluginSDK.h"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <string>
#include <vector>

POEFIXER_PLUGIN_INFO(
    "PartyPlayChecker",
    "Party Play Checker",
    "0.1.0",
    "PartyPlayChecker contributors",
    "Shows the distance to nearby players and whether they are within your chosen range.")

namespace {

struct NearbyPlayer {
    std::string name;
    float distanceMeters = 0.0f;
};

std::string ToUtf8(const std::wstring& value) {
    if (value.empty()) return {};
    const int needed = WideCharToMultiByte(CP_UTF8, 0, value.data(),
        static_cast<int>(value.size()), nullptr, 0, nullptr, nullptr);
    if (needed <= 0) return {};
    std::string result(static_cast<size_t>(needed), '\0');
    WideCharToMultiByte(CP_UTF8, 0, value.data(), static_cast<int>(value.size()),
        result.data(), needed, nullptr, nullptr);
    return result;
}

} // namespace

class PartyPlayChecker final : public PluginSDK::Plugin {
public:
    const char* GetName() const override { return "Party Play Checker"; }
    bool WantsOverlay() const override { return true; }

    void OnEnable(bool) override {
        if (ctx()->ImGuiContext)
            ImGui::SetCurrentContext(static_cast<ImGuiContext*>(ctx()->ImGuiContext));
        LoadSettings();
    }

    void OnDisable() override { SaveSettings(); }

    void SaveSettings() override {
        const auto path = DirectoryPath() / L"settings.ini";
        std::ofstream file(path, std::ios::trunc);
        if (!file) return;
        file << "distance_limit_m=" << m_distanceLimitMeters << '\n';
        file << "show_players_outside_range=" << (m_showPlayersOutsideRange ? 1 : 0) << '\n';
        file << "show_overlay=" << (m_showOverlay ? 1 : 0) << '\n';
    }

    void DrawSettings() override {
        if (ctx()->ImGuiContext)
            ImGui::SetCurrentContext(static_cast<ImGuiContext*>(ctx()->ImGuiContext));

        ImGui::TextUnformatted("Party Play Checker");
        ImGui::TextWrapped("Mesure la distance horizontale entre ton personnage et les autres joueurs visibles dans la zone.");
        ImGui::Spacing();
        ImGui::SliderFloat("Seuil de proximité (m)", &m_distanceLimitMeters, 1.0f, 100.0f, "%.1f m");
        ImGui::Checkbox("Afficher aussi les joueurs hors seuil", &m_showPlayersOutsideRange);
        ImGui::Checkbox("Afficher le panneau en jeu", &m_showOverlay);
        ImGui::TextWrapped("13 m par défaut : ancienne référence du bonus de butin de PoE 1, non confirmée pour PoE 2.");
        ImGui::TextWrapped("Aucune portée unique confirmée pour tous les bonus de groupe PoE 2. Le SDK ne confirme ni l'appartenance au groupe ni l'éligibilité effective à l'XP ou au butin.");
        if (ImGui::Button("Enregistrer les réglages")) SaveSettings();
    }

    void DrawUI() override {
        if (!m_showOverlay || !ctx()->Game.IsInGame() || !ctx()->Game.IsForeground()) return;
        if (ctx()->ImGuiContext)
            ImGui::SetCurrentContext(static_cast<ImGuiContext*>(ctx()->ImGuiContext));

        const PluginSDK::Entity self = ctx()->Entities.GetPlayer();
        if (!self.IsValid || self.EntitySubtype != PluginSDK::EntitySubtype::PlayerSelf) return;

        std::vector<NearbyPlayer> players;
        ctx()->Entities.Enumerate([&](const PluginSDK::Entity& entity) {
            if (!entity.IsValid || entity.EntityType != PluginSDK::EntityType::Player ||
                entity.EntitySubtype != PluginSDK::EntitySubtype::PlayerOther ||
                entity.RenderComponentAddress == 0)
                return true;

            const float dx = entity.WorldX - self.WorldX;
            const float dy = entity.WorldY - self.WorldY;
            const float distance = std::sqrt(dx * dx + dy * dy);
            if (!std::isfinite(distance)) return true;

            std::string name = ToUtf8(entity.PlayerName);
            if (name.empty()) name = "Joueur sans nom";
            players.push_back({ std::move(name), distance });
            return true;
        });

        std::sort(players.begin(), players.end(), [](const auto& a, const auto& b) {
            return a.distanceMeters < b.distanceMeters;
        });

        const float panelWidth = 310.0f;
        const float x = std::max(12.0f, ImGui::GetIO().DisplaySize.x - panelWidth - 18.0f);
        ImGui::SetNextWindowPos(ImVec2(x, 18.0f), ImGuiCond_Always);
        ImGui::SetNextWindowBgAlpha(0.82f);
        const ImGuiWindowFlags flags = ImGuiWindowFlags_AlwaysAutoResize |
            ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoInputs |
            ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing |
            ImGuiWindowFlags_NoNav;

        if (!ImGui::Begin("Party Play Checker###PartyPlayCheckerOverlay", nullptr, flags)) {
            ImGui::End();
            return;
        }

        ImGui::Text("Party Play Checker  |  seuil %.1f m", m_distanceLimitMeters);
        ImGui::Separator();
        if (players.empty()) {
            ImGui::TextUnformatted("Aucun autre joueur détecté dans la zone.");
        } else {
            size_t shown = 0;
            for (const auto& player : players) {
                const bool inRange = player.distanceMeters <= m_distanceLimitMeters;
                if (!m_showPlayersOutsideRange && !inRange) continue;
                const ImVec4 color = inRange ? ImVec4(0.30f, 0.92f, 0.48f, 1.0f)
                                             : ImVec4(1.0f, 0.55f, 0.34f, 1.0f);
                ImGui::TextColored(color, "%s  %.1f m  %s", player.name.c_str(),
                    player.distanceMeters, inRange ? "DANS LE SEUIL" : "HORS SEUIL");
                ++shown;
            }
            if (shown == 0) ImGui::TextUnformatted("Aucun joueur dans le seuil choisi.");
        }
        ImGui::End();
    }

private:
    void LoadSettings() {
        const auto path = DirectoryPath() / L"settings.ini";
        std::ifstream file(path);
        std::string line;
        while (std::getline(file, line)) {
            const auto split = line.find('=');
            if (split == std::string::npos) continue;
            const std::string key = line.substr(0, split);
            const std::string value = line.substr(split + 1);
            if (key == "distance_limit_m") {
                try {
                    const float parsed = std::stof(value);
                    if (std::isfinite(parsed)) m_distanceLimitMeters = std::clamp(parsed, 1.0f, 100.0f);
                } catch (...) {}
            } else if (key == "show_players_outside_range") {
                m_showPlayersOutsideRange = value != "0";
            } else if (key == "show_overlay") {
                m_showOverlay = value != "0";
            }
        }
    }

    float m_distanceLimitMeters = 13.0f;
    bool m_showPlayersOutsideRange = true;
    bool m_showOverlay = true;
};

extern "C" PLUGIN_API PluginSDK::Plugin* CreatePlugin() { return new PartyPlayChecker(); }
extern "C" PLUGIN_API void DestroyPlugin(PluginSDK::Plugin* plugin) { delete plugin; }

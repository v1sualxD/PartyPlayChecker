# Party Play Checker

Plugin POEFixer (SDK v6), compilable en DLL x64 avec Visual Studio 2022 / MSVC v143.

## Fonctions

- Détecte les autres entités joueur visibles dans la zone.
- Affiche leur distance horizontale depuis ton personnage, arrondie à 0,1 m.
- Indique si chaque joueur se trouve dans le seuil réglable de 1 à 100 m.
- Permet de régler le seuil et l'affichage; `settings.ini` est enregistré à côté du plugin.

## Ce que la recherche confirme

La documentation de PoE 2 décrit les bonus de butin comme dépendant des joueurs « nearby », sans publier de rayon numérique. Sa page de référence sur les distances confirme que les distances de jeu sont exprimées en mètres, mais ne donne pas de portée de groupe. La valeur 13 m que l'on trouve dans les références de party play correspond au bonus de butin de Path of Exile 1 et ne permet pas de conclure pour PoE 2 ni pour le partage d'XP.

Le seuil initial de 13 m est donc un repère provisoire facile à modifier, pas une portée PoE 2 vérifiée. Le SDK POEFixer donne les coordonnées et les noms des joueurs détectés, mais pas l'appartenance au groupe ni l'éligibilité exacte aux gains d'XP ou de butin. Le statut signifie uniquement « dans le seuil choisi ».

Références : [Party play PoE 2](https://www.poe2wiki.net/wiki/Party), [distances dans PoE 2](https://www.poe2wiki.net/wiki/Nearby), [party play PoE 1 — référence des 13 m](https://www.poewiki.net/wiki/Partying).

## Compilation et installation

Ouvre `PartyPlayChecker.sln`, sélectionne `Release | x64`, puis compile. Copie `x64/Release/Plugins/PartyPlayChecker/PartyPlayChecker.dll` dans `POEFixer/Plugins/PartyPlayChecker/` et active-le dans le gestionnaire de plugins POEFixer.

Le SDK et les sources ImGui sont inclus dans `POEFixer/` pour compiler sans autre checkout. Voir `LICENSE` pour la licence et les crédits amont.
